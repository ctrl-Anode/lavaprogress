<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Membership Applications</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .timeline {
            position: relative;
            padding: 20px 0;
        }
        .timeline-item {
            position: relative;
            padding-left: 40px;
            margin-bottom: 30px;
        }
        .timeline-item:before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: -30px;
            width: 2px;
            background: #dee2e6;
        }
        .timeline-item:last-child:before {
            bottom: 0;
        }
        .timeline-badge {
            position: absolute;
            left: -10px;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #fff;
            border: 2px solid;
        }
        .timeline-content {
            padding: 15px;
            border-radius: 4px;
            background: #f8f9fa;
        }
    </style>
</head>
<body>
    <?php include 'app/views/templates/sidenav.php'; ?>

    <div class="container mt-4">
        <h1 class="mb-4">My Membership Applications</h1>

        <?php if (isset($_SESSION['alert'])) : ?>
            <div class="alert alert-<?= $_SESSION['alert']['type'] ?> alert-dismissible fade show" role="alert">
                <?= $_SESSION['alert']['message'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Applications Timeline -->
        <div class="card mb-4">
            <div class="card-body">
                <?php if (!empty($applications)) : ?>
                    <div class="timeline">
                        <?php foreach ($applications as $application) : ?>
                            <div class="timeline-item">
                                <div class="timeline-badge border-<?php
                                    switch ($application['Status']) {
                                        case 'pending': echo 'warning'; break;
                                        case 'approved': echo 'success'; break;
                                        case 'rejected': echo 'danger'; break;
                                        default: echo 'secondary';
                                    }
                                ?>"></div>
                                <div class="timeline-content">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <h5 class="mb-0"><?= $application['MembershipType'] ?></h5>
                                        <span class="badge bg-<?php
                                            switch ($application['Status']) {
                                                case 'pending': echo 'warning'; break;
                                                case 'approved': echo 'success'; break;
                                                case 'rejected': echo 'danger'; break;
                                                default: echo 'secondary';
                                            }
                                        ?>">
                                            <?= ucfirst($application['Status']) ?>
                                        </span>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p class="mb-1">
                                                <strong>Applied Date:</strong> 
                                                <?= date('F d, Y', strtotime($application['AppliedDate'])) ?>
                                            </p>
                                            <p class="mb-1">
                                                <strong>Price:</strong> 
                                                $<?= number_format($application['MembershipPrice'], 2) ?>
                                            </p>
                                        </div>
                                        <div class="col-md-6">
                                            <?php if (isset($application['ApprovedDate'])) : ?>
                                                <p class="mb-1">
                                                    <strong>Approved Date:</strong>
                                                    <?= date('F d, Y', strtotime($application['ApprovedDate'])) ?>
                                                </p>
                                            <?php endif; ?>
                                            <?php if (!empty($application['Notes'])) : ?>
                                                <p class="mb-1">
                                                    <strong>Notes:</strong>
                                                    <?= $application['Notes'] ?>
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <?php if (isset($application['PaymentStatus'])) : ?>
                                        <div class="mt-3 p-2 bg-light rounded">
                                            <h6 class="mb-2">Payment Information</h6>
                                            <p class="mb-1">
                                                <strong>Status:</strong>
                                                <span class="badge bg-<?php
                                                    switch ($application['PaymentStatus']) {
                                                        case 'pending': echo 'warning'; break;
                                                        case 'completed': echo 'success'; break;
                                                        case 'failed': echo 'danger'; break;
                                                        case 'refunded': echo 'info'; break;
                                                        default: echo 'secondary';
                                                    }
                                                ?>">
                                                    <?= ucfirst($application['PaymentStatus']) ?>
                                                </span>
                                            </p>
                                            <?php if (isset($application['PaymentDate'])) : ?>
                                                <p class="mb-1">
                                                    <strong>Payment Date:</strong>
                                                    <?= date('F d, Y', strtotime($application['PaymentDate'])) ?>
                                                </p>
                                            <?php endif; ?>
                                            <?php if (isset($application['TransactionID'])) : ?>
                                                <p class="mb-1">
                                                    <strong>Transaction ID:</strong>
                                                    <?= $application['TransactionID'] ?>
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>

                                    <?php if ($application['Status'] === 'approved' && 
                                            isset($application['PaymentStatus']) && 
                                            $application['PaymentStatus'] === 'pending') : ?>
                                        <div class="mt-3">
                                            <a href="#" class="btn btn-primary">Complete Payment</a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else : ?>
                    <div class="text-center py-4">
                        <h5>No applications found</h5>
                        <p>You haven't applied for any memberships yet.</p>
                        <a href="<?= site_url('memberships/available_memberships') ?>" class="btn btn-primary">
                            View Available Memberships
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Application Status Guide -->
        <div class="card">
            <div class="card-body">
                <h4>Understanding Application Status</h4>
                <div class="row mt-3">
                    <div class="col-md-3">
                        <div class="d-flex align-items-center mb-2">
                            <span class="badge bg-warning me-2">Pending</span>
                            <span>Application is under review</span>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="d-flex align-items-center mb-2">
                            <span class="badge bg-success me-2">Approved</span>
                            <span>Application has been accepted</span>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="d-flex align-items-center mb-2">
                            <span class="badge bg-danger me-2">Rejected</span>
                            <span>Application was not approved</span>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="d-flex align-items-center mb-2">
                            <span class="badge bg-secondary me-2">Cancelled</span>
                            <span>Application was cancelled</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
