<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Membership Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'app/views/templates/sidenav.php'; ?>

    <div class="container mt-4">
        <h1 class="mb-4">My Membership Dashboard</h1>

        <?php if (isset($_SESSION['alert'])) : ?>
            <div class="alert alert-<?= $_SESSION['alert']['type'] ?> alert-dismissible fade show" role="alert">
                <?= $_SESSION['alert']['message'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Active Membership Section -->
        <div class="card mb-4">
            <div class="card-header">
                <h4>Active Membership</h4>
            </div>
            <div class="card-body">
                <?php if (isset($active_membership) && $active_membership) : ?>
                    <div class="row">
                        <div class="col-md-6">
                            <h5><?= $active_membership['MembershipType'] ?></h5>
                            <p><strong>Start Date:</strong> <?= date('F d, Y', strtotime($active_membership['StartDate'])) ?></p>
                            <p><strong>End Date:</strong> <?= date('F d, Y', strtotime($active_membership['EndDate'])) ?></p>
                            <p><strong>Status:</strong> 
                                <span class="badge bg-<?= $active_membership['Status'] === 'active' ? 'success' : 'warning' ?>">
                                    <?= ucfirst($active_membership['Status']) ?>
                                </span>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Price:</strong> $<?= number_format($active_membership['MembershipPrice'], 2) ?></p>
                            <p><strong>Benefits:</strong> <?= $active_membership['MembershipInfo'] ?></p>
                            
                            <!-- Membership Actions -->
                            <div class="mt-3">
                                <?php if ($active_membership['Status'] === 'active') : ?>
                                    <!-- Renew Button -->
                                    <form action="<?= site_url('memberships/renew_membership') ?>" method="post" class="d-inline">
                                        <input type="hidden" name="user_membership_id" value="<?= $active_membership['UserMembershipID'] ?>">
                                        <button type="submit" class="btn btn-primary">Renew Membership</button>
                                    </form>
                                    
                                    <!-- Cancel Button -->
                                    <form action="<?= site_url('memberships/cancel_membership') ?>" method="post" class="d-inline">
                                        <input type="hidden" name="user_membership_id" value="<?= $active_membership['UserMembershipID'] ?>">
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to cancel your membership?')">
                                            Cancel Membership
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php else : ?>
                    <p>You don't have an active membership.</p>
                    <a href="<?= site_url('memberships/available_memberships') ?>" class="btn btn-primary">View Available Memberships</a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Applications Section -->
        <div class="card mb-4">
            <div class="card-header">
                <h4>Recent Applications</h4>
            </div>
            <div class="card-body">
                <?php if (!empty($recent_applications)) : ?>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Membership Type</th>
                                    <th>Applied Date</th>
                                    <th>Status</th>
                                    <th>Price</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_applications as $application) : ?>
                                    <tr>
                                        <td><?= $application['MembershipType'] ?></td>
                                        <td><?= date('F d, Y', strtotime($application['AppliedDate'])) ?></td>
                                        <td>
                                            <span class="badge bg-<?php
                                                switch ($application['Status']) {
                                                    case 'pending': echo 'warning'; break;
                                                    case 'approved': echo 'success'; break;
                                                    case 'rejected': echo 'danger'; break;
                                                    default: echo 'secondary';
                                                }
                                            ?>">
                                                <?= ucfirst($application['Status']) ?>
                                            </span>
                                        </td>
                                        <td>$<?= number_format($application['MembershipPrice'], 2) ?></td>
                                        <td><?= $application['Notes'] ?? 'No notes' ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <a href="<?= site_url('memberships/my_applications') ?>" class="btn btn-secondary">View All Applications</a>
                <?php else : ?>
                    <p>No recent applications found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
