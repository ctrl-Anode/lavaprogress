<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add New Membership - Gym Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .form-container {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .required::after {
            content: "*";
            color: red;
            margin-left: 4px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Include Sidebar -->
            <?php include 'app/views/templates/sidenav.php'; ?>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Add New Membership</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="<?= site_url('admin/memberships'); ?>" class="btn btn-secondary">
                            <i class="bi bi-arrow-left me-1"></i>Back to List
                        </a>
                    </div>
                </div>

                <?php flash_alert(); ?>

                <div class="form-container">
                    <form action="<?= site_url('admin/memberships/create'); ?>" method="POST" class="needs-validation" novalidate>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="MembershipType" class="form-label required">Membership Type</label>
                                <input type="text" class="form-control" id="MembershipType" name="MembershipType" 
                                       required maxlength="100" value="<?= isset($_POST['MembershipType']) ? html_escape($_POST['MembershipType']) : ''; ?>">
                                <div class="invalid-feedback">Please enter a membership type.</div>
                            </div>

                            <div class="col-md-6">
                                <label for="MembershipPrice" class="form-label required">Price</label>
                                <div class="input-group">
                                    <span class="input-group-text">₱</span>
                                    <input type="number" step="0.01" min="0" class="form-control" id="MembershipPrice" 
                                           name="MembershipPrice" required value="<?= isset($_POST['MembershipPrice']) ? html_escape($_POST['MembershipPrice']) : ''; ?>">
                                    <div class="invalid-feedback">Please enter a valid price.</div>
                                </div>
                            </div>

                            <div class="col-12">
                                <label for="MembershipInfo" class="form-label required">Description</label>
                                <textarea class="form-control" id="MembershipInfo" name="MembershipInfo" 
                                          rows="4" required><?= isset($_POST['MembershipInfo']) ? html_escape($_POST['MembershipInfo']) : ''; ?></textarea>
                                <div class="invalid-feedback">Please provide membership details.</div>
                                <div class="form-text">Describe the features and benefits of this membership plan.</div>
                            </div>

                            <div class="col-md-6">
                                <label for="DurationInMonths" class="form-label required">Duration (Months)</label>
                                <input type="number" class="form-control" id="DurationInMonths" name="DurationInMonths" 
                                       min="1" max="60" required value="<?= isset($_POST['DurationInMonths']) ? html_escape($_POST['DurationInMonths']) : '1'; ?>">
                                <div class="invalid-feedback">Please enter a valid duration (1-60 months).</div>
                            </div>

                            <div class="col-12 mt-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-plus-circle me-1"></i>Create Membership Plan
                                </button>
                                <button type="reset" class="btn btn-outline-secondary ms-2">
                                    <i class="bi bi-arrow-counterclockwise me-1"></i>Reset Form
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        (function () {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms).forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }
                    form.classList.add('was-validated')
                }, false)
            })
        })()

        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
                alerts.forEach(function(alert) {
                    bootstrap.Alert.getOrCreateInstance(alert).close();
                });
            }, 5000);
        });
    </script>
</body>
</html>
