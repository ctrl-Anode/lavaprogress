<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Memberships</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>Available Memberships</h1>
        <div class="row">
            <?php foreach ($memberships as $membership): ?>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title"><?= html_escape($membership['MembershipType']); ?></h5>
                            <p class="card-text">Price: $<?= html_escape($membership['MembershipPrice']); ?></p>
                            <p class="card-text"><?= html_escape($membership['MembershipInfo']); ?></p>
                            <a href="<?= site_url('memberships/book_class/' . $membership['MembershipID']); ?>" class="btn btn-primary">Book Now</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>