<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Membership Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .stat-card {
            transition: transform 0.2s;
            cursor: pointer;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .quick-action-btn {
            min-width: 200px;
            margin-bottom: 10px;
        }
        .status-indicator {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
        }
        .status-active { background-color: #28a745; }
        .status-pending { background-color: #ffc107; }
        .status-expired { background-color: #dc3545; }
    </style>
</head>
<body>
    <?php include 'app/views/templates/sidenav.php'; ?>

    <div class="container-fluid mt-4 px-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>Membership Management Dashboard</h1>
            <div>
                <button class="btn btn-outline-secondary" onclick="window.location.reload();">
                    <i class="bi bi-arrow-clockwise"></i> Refresh Data
                </button>
            </div>
        </div>

        <?php if (isset($_SESSION['alert'])) : ?>
            <div class="alert alert-<?= $_SESSION['alert']['type'] ?> alert-dismissible fade show" role="alert">
                <?= $_SESSION['alert']['message'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Quick Actions -->
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0"><i class="bi bi-lightning-charge"></i> Quick Actions</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 text-center">
                                <a href="<?= site_url('memberships/create') ?>" class="btn btn-primary quick-action-btn">
                                    <i class="bi bi-plus-circle"></i> Create New Membership
                                </a>
                            </div>
                            <div class="col-md-3 text-center">
                                <a href="<?= site_url('memberships/read') ?>" class="btn btn-info quick-action-btn">
                                    <i class="bi bi-card-list"></i> View All Memberships
                                </a>
                            </div>
                            <div class="col-md-3 text-center">
                                <a href="<?= site_url('memberships/manage_applications') ?>" class="btn btn-success quick-action-btn">
                                    <i class="bi bi-people"></i> Manage Applications
                                </a>
                            </div>
                            <div class="col-md-3 text-center">
                                <div class="dropdown">
                                    <button class="btn btn-warning quick-action-btn dropdown-toggle" type="button" id="maintenanceDropdown" data-bs-toggle="dropdown">
                                        <i class="bi bi-gear"></i> Maintenance
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a class="dropdown-item" href="<?= site_url('memberships/check_expiring_memberships') ?>">
                                                <i class="bi bi-clock-history"></i> Check Expiring Memberships
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="<?= site_url('memberships/expire_memberships') ?>">
                                                <i class="bi bi-x-circle"></i> Process Expired Memberships
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-header bg-info text-white">
                        <h4 class="mb-0"><i class="bi bi-graph-up"></i> Application Statistics</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <div class="card stat-card bg-primary text-white">
                                    <div class="card-body text-center">
                                        <i class="bi bi-collection fs-1"></i>
                                        <h5 class="card-title mt-2">Total Applications</h5>
                                        <h2><?= $stats['total'] ?? 0 ?></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="card stat-card bg-warning text-dark">
                                    <div class="card-body text-center">
                                        <i class="bi bi-hourglass-split fs-1"></i>
                                        <h5 class="card-title mt-2">Pending</h5>
                                        <h2><?= $stats['pending'] ?? 0 ?></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="card stat-card bg-success text-white">
                                    <div class="card-body text-center">
                                        <i class="bi bi-check-circle fs-1"></i>
                                        <h5 class="card-title mt-2">Approved</h5>
                                        <h2><?= $stats['approved'] ?? 0 ?></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="card stat-card bg-danger text-white">
                                    <div class="card-body text-center">
                                        <i class="bi bi-x-circle fs-1"></i>
                                        <h5 class="card-title mt-2">Rejected</h5>
                                        <h2><?= $stats['rejected'] ?? 0 ?></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="card stat-card bg-secondary text-white">
                                    <div class="card-body text-center">
                                        <i class="bi bi-dash-circle fs-1"></i>
                                        <h5 class="card-title mt-2">Cancelled</h5>
                                        <h2><?= $stats['cancelled'] ?? 0 ?></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Applications -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-success text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="mb-0"><i class="bi bi-clock-history"></i> Recent Applications</h4>
                    <a href="<?= site_url('memberships/manage_applications') ?>" class="btn btn-light btn-sm">
                        View All Applications
                    </a>
                </div>
            </div>
            <div class="card-body">
                <?php if (!empty($recent_applications)) : ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>User</th>
                                    <th>Membership Type</th>
                                    <th>Applied Date</th>
                                    <th>Status</th>
                                    <th>Price</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_applications as $application) : ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="status-indicator status-<?= strtolower($application['Status']) ?>"></div>
                                                <div>
                                                    <strong><?= $application['username'] ?></strong><br>
                                                    <small class="text-muted"><?= $application['email'] ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?= $application['MembershipType'] ?></td>
                                        <td><?= date('F d, Y', strtotime($application['AppliedDate'])) ?></td>
                                        <td>
                                            <span class="badge bg-<?php
                                                switch ($application['Status']) {
                                                    case 'pending': echo 'warning'; break;
                                                    case 'approved': echo 'success'; break;
                                                    case 'rejected': echo 'danger'; break;
                                                    default: echo 'secondary';
                                                }
                                            ?>">
                                                <?= ucfirst($application['Status']) ?>
                                            </span>
                                        </td>
                                        <td>$<?= number_format($application['MembershipPrice'], 2) ?></td>
                                        <td>
                                            <?php if ($application['Status'] === 'pending') : ?>
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-success btn-sm" 
                                                            data-bs-toggle="modal" 
                                                            data-bs-target="#approveModal<?= $application['ApplicationID'] ?>">
                                                        <i class="bi bi-check-lg"></i> Approve
                                                    </button>
                                                    <button type="button" class="btn btn-danger btn-sm"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#rejectModal<?= $application['ApplicationID'] ?>">
                                                        <i class="bi bi-x-lg"></i> Reject
                                                    </button>
                                                </div>

                                                <!-- Approve Modal -->
                                                <div class="modal fade" id="approveModal<?= $application['ApplicationID'] ?>" tabindex="-1">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <form action="<?= site_url('memberships/update_application_status') ?>" method="post">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Approve Application</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <input type="hidden" name="application_id" value="<?= $application['ApplicationID'] ?>">
                                                                    <input type="hidden" name="status" value="approved">
                                                                    <div class="mb-3">
                                                                        <label for="notes" class="form-label">Notes (Optional)</label>
                                                                        <textarea name="notes" class="form-control" rows="3" 
                                                                                  placeholder="Add any additional notes..."></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                                    <button type="submit" class="btn btn-success">
                                                                        <i class="bi bi-check-lg"></i> Approve Application
                                                                    </button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Reject Modal -->
                                                <div class="modal fade" id="rejectModal<?= $application['ApplicationID'] ?>" tabindex="-1">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <form action="<?= site_url('memberships/update_application_status') ?>" method="post">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Reject Application</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <input type="hidden" name="application_id" value="<?= $application['ApplicationID'] ?>">
                                                                    <input type="hidden" name="status" value="rejected">
                                                                    <div class="mb-3">
                                                                        <label for="notes" class="form-label">Reason for Rejection</label>
                                                                        <textarea name="notes" class="form-control" rows="3" required
                                                                                  placeholder="Please provide a reason for rejection..."></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                                    <button type="submit" class="btn btn-danger">
                                                                        <i class="bi bi-x-lg"></i> Reject Application
                                                                    </button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else : ?>
                                                <span class="text-muted">No actions available</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else : ?>
                    <div class="text-center py-4">
                        <i class="bi bi-inbox fs-1 text-muted"></i>
                        <p class="mt-2">No recent applications found.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Enable tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        })

        // Auto-hide alerts after 5 seconds
        window.setTimeout(function() {
            document.querySelectorAll('.alert').forEach(function(alert) {
                var bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html>
