<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Manage Memberships - Gym Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .table-container {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .action-links .btn {
            margin-right: 5px;
        }
        .price {
            font-family: monospace;
        }
        .membership-info {
            max-width: 300px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Include Sidebar -->
            <?php include 'app/views/templates/sidenav.php'; ?>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Manage Memberships</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="<?= site_url('admin/memberships/create'); ?>" class="btn btn-primary">
                            <i class="bi bi-plus-circle me-1"></i>Add New Membership
                        </a>
                    </div>
                </div>

                <?php flash_alert(); ?>

                <div class="table-container">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover align-middle">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Type</th>
                                    <th>Price</th>
                                    <th>Info</th>
                                    <th>Duration</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($memberships)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-4">No membership plans found.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($memberships as $membership): ?>
                                        <tr>
                                            <td><?= $membership['MembershipID']; ?></td>
                                            <td><?= html_escape($membership['MembershipType']); ?></td>
                                            <td class="price">₱<?= number_format($membership['MembershipPrice'], 2); ?></td>
                                            <td class="membership-info" title="<?= html_escape($membership['MembershipInfo']); ?>">
                                                <?= html_escape($membership['MembershipInfo']); ?>
                                            </td>
                                            <td><?= $membership['DurationInMonths']; ?> months</td>
                                            <td>
                                                <span class="badge bg-<?= $membership['Status'] === 'active' ? 'success' : 'danger'; ?>">
                                                    <?= ucfirst($membership['Status']); ?>
                                                </span>
                                            </td>
                                            <td class="action-links">
                                                <a href="<?= site_url('admin/memberships/update/' . $membership['MembershipID']); ?>" 
                                                   class="btn btn-sm btn-warning" title="Edit">
                                                    <i class="bi bi-pencil-square"></i>
                                                </a>
                                                <button type="button" class="btn btn-sm btn-danger" 
                                                        onclick="confirmDelete(<?= $membership['MembershipID']; ?>)" title="Delete">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this membership plan? This action cannot be undone.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a href="#" id="confirmDeleteBtn" class="btn btn-danger">Delete</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function confirmDelete(id) {
            const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
            document.getElementById('confirmDeleteBtn').href = '<?= site_url("admin/memberships/delete/"); ?>' + id;
            modal.show();
        }

        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
                alerts.forEach(function(alert) {
                    bootstrap.Alert.getOrCreateInstance(alert).close();
                });
            }, 5000);
        });
    </script>
</body>
</html>
