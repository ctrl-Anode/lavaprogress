<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Membership</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .membership-card {
            border-left: 5px solid;
        }
        .membership-active {
            border-left-color: #198754;
        }
        .membership-expired {
            border-left-color: #dc3545;
        }
        .membership-cancelled {
            border-left-color: #6c757d;
        }
        .history-card {
            transition: transform 0.2s;
        }
        .history-card:hover {
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <?php include 'app/views/templates/sidenav.php'; ?>

    <div class="container mt-4">
        <h1 class="mb-4">My Membership</h1>

        <?php if (isset($_SESSION['alert'])) : ?>
            <div class="alert alert-<?= $_SESSION['alert']['type'] ?> alert-dismissible fade show" role="alert">
                <?= $_SESSION['alert']['message'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Active Membership Section -->
        <div class="card mb-4">
            <div class="card-header">
                <h4>Current Membership</h4>
            </div>
            <div class="card-body">
                <?php if (isset($active_membership) && $active_membership) : ?>
                    <div class="card membership-card membership-<?= $active_membership['Status'] ?>">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <h3 class="card-title"><?= $active_membership['MembershipType'] ?></h3>
                                    <div class="mb-3">
                                        <span class="badge bg-<?= $active_membership['Status'] === 'active' ? 'success' : 'danger' ?>">
                                            <?= ucfirst($active_membership['Status']) ?>
                                        </span>
                                    </div>
                                    <p class="card-text"><?= nl2br($active_membership['MembershipInfo']) ?></p>
                                </div>
                                <div class="col-md-4 text-md-end">
                                    <p class="h4 text-primary mb-2">$<?= number_format($active_membership['MembershipPrice'], 2) ?></p>
                                    <p class="text-muted">
                                        Valid until: <?= date('F d, Y', strtotime($active_membership['EndDate'])) ?>
                                    </p>
                                </div>
                            </div>

                            <?php if ($active_membership['Status'] === 'active') : ?>
                                <div class="mt-3">
                                    <?php
                                    $days_remaining = ceil((strtotime($active_membership['EndDate']) - time()) / (60 * 60 * 24));
                                    $progress = 100 - (($days_remaining / (30 * $active_membership['DurationInMonths'])) * 100);
                                    ?>
                                    <h6>Membership Progress</h6>
                                    <div class="progress" style="height: 20px;">
                                        <div class="progress-bar <?= $days_remaining <= 7 ? 'bg-warning' : 'bg-success' ?>" 
                                             role="progressbar" 
                                             style="width: <?= $progress ?>%"
                                             aria-valuenow="<?= $progress ?>" 
                                             aria-valuemin="0" 
                                             aria-valuemax="100">
                                            <?= $days_remaining ?> days remaining
                                        </div>
                                    </div>

                                    <div class="mt-3">
                                        <?php if ($days_remaining <= 30) : ?>
                                            <form action="<?= site_url('memberships/renew_membership') ?>" method="post" class="d-inline">
                                                <input type="hidden" name="user_membership_id" value="<?= $active_membership['UserMembershipID'] ?>">
                                                <button type="submit" class="btn btn-primary">Renew Membership</button>
                                            </form>
                                        <?php endif; ?>

                                        <form action="<?= site_url('memberships/cancel_membership') ?>" method="post" class="d-inline">
                                            <input type="hidden" name="user_membership_id" value="<?= $active_membership['UserMembershipID'] ?>">
                                            <button type="submit" class="btn btn-outline-danger" 
                                                    onclick="return confirm('Are you sure you want to cancel your membership? This action cannot be undone.')">
                                                Cancel Membership
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php else : ?>
                    <div class="text-center py-4">
                        <p>You don't have an active membership.</p>
                        <a href="<?= site_url('memberships/available_memberships') ?>" class="btn btn-primary">
                            View Available Memberships
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Membership History Section -->
        <div class="card">
            <div class="card-header">
                <h4>Membership History</h4>
            </div>
            <div class="card-body">
                <?php if (!empty($membership_history)) : ?>
                    <div class="row row-cols-1 row-cols-md-2 g-4">
                        <?php foreach ($membership_history as $membership) : ?>
                            <div class="col">
                                <div class="card history-card h-100">
                                    <div class="card-body">
                                        <h5 class="card-title"><?= $membership['MembershipType'] ?></h5>
                                        <div class="mb-2">
                                            <span class="badge bg-<?php
                                                switch ($membership['Status']) {
                                                    case 'active': echo 'success'; break;
                                                    case 'expired': echo 'danger'; break;
                                                    case 'cancelled': echo 'secondary'; break;
                                                    default: echo 'info';
                                                }
                                            ?>">
                                                <?= ucfirst($membership['Status']) ?>
                                            </span>
                                        </div>
                                        <p class="card-text">
                                            <small class="text-muted">
                                                From: <?= date('F d, Y', strtotime($membership['StartDate'])) ?><br>
                                                To: <?= date('F d, Y', strtotime($membership['EndDate'])) ?>
                                            </small>
                                        </p>
                                        <p class="card-text">
                                            <strong>Price:</strong> $<?= number_format($membership['MembershipPrice'], 2) ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else : ?>
                    <p class="text-center py-3">No membership history found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
