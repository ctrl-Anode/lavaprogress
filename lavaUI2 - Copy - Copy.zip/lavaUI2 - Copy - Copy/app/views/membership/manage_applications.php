<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Membership Applications</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'app/views/templates/sidenav.php'; ?>

    <div class="container mt-4">
        <h1 class="mb-4">Manage Membership Applications</h1>

        <?php if (isset($_SESSION['alert'])) : ?>
            <div class="alert alert-<?= $_SESSION['alert']['type'] ?> alert-dismissible fade show" role="alert">
                <?= $_SESSION['alert']['message'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Applications Table -->
        <div class="card">
            <div class="card-header">
                <h4>All Applications</h4>
            </div>
            <div class="card-body">
                <?php if (!empty($applications)) : ?>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Membership Type</th>
                                    <th>Applied Date</th>
                                    <th>Status</th>
                                    <th>Price</th>
                                    <th>Payment Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($applications as $application) : ?>
                                    <tr>
                                        <td>
                                            <?= $application['username'] ?><br>
                                            <small class="text-muted"><?= $application['email'] ?></small>
                                        </td>
                                        <td><?= $application['MembershipType'] ?></td>
                                        <td><?= date('F d, Y', strtotime($application['AppliedDate'])) ?></td>
                                        <td>
                                            <span class="badge bg-<?php
                                                switch ($application['Status']) {
                                                    case 'pending': echo 'warning'; break;
                                                    case 'approved': echo 'success'; break;
                                                    case 'rejected': echo 'danger'; break;
                                                    default: echo 'secondary';
                                                }
                                            ?>">
                                                <?= ucfirst($application['Status']) ?>
                                            </span>
                                        </td>
                                        <td>$<?= number_format($application['MembershipPrice'], 2) ?></td>
                                        <td>
                                            <?php if (isset($application['PaymentStatus'])) : ?>
                                                <span class="badge bg-<?php
                                                    switch ($application['PaymentStatus']) {
                                                        case 'pending': echo 'warning'; break;
                                                        case 'completed': echo 'success'; break;
                                                        case 'failed': echo 'danger'; break;
                                                        case 'refunded': echo 'info'; break;
                                                        default: echo 'secondary';
                                                    }
                                                ?>">
                                                    <?= ucfirst($application['PaymentStatus']) ?>
                                                </span>
                                            <?php else : ?>
                                                <span class="badge bg-secondary">Not Available</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <!-- Application Status Actions -->
                                            <?php if ($application['Status'] === 'pending') : ?>
                                                <button type="button" class="btn btn-success btn-sm mb-1" data-bs-toggle="modal" data-bs-target="#approveModal<?= $application['ApplicationID'] ?>">
                                                    Approve
                                                </button>
                                                <button type="button" class="btn btn-danger btn-sm mb-1" data-bs-toggle="modal" data-bs-target="#rejectModal<?= $application['ApplicationID'] ?>">
                                                    Reject
                                                </button>
                                            <?php endif; ?>

                                            <!-- Payment Status Actions -->
                                            <?php if (isset($application['PaymentStatus']) && $application['PaymentStatus'] === 'pending') : ?>
                                                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#paymentModal<?= $application['ApplicationID'] ?>">
                                                    Update Payment
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <!-- Approve Modal -->
                                    <div class="modal fade" id="approveModal<?= $application['ApplicationID'] ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?= site_url('memberships/update_application_status') ?>" method="post">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Approve Application</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="application_id" value="<?= $application['ApplicationID'] ?>">
                                                        <input type="hidden" name="status" value="approved">
                                                        <div class="mb-3">
                                                            <label for="notes" class="form-label">Notes (Optional)</label>
                                                            <textarea name="notes" class="form-control" rows="3"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-success">Approve</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Reject Modal -->
                                    <div class="modal fade" id="rejectModal<?= $application['ApplicationID'] ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?= site_url('memberships/update_application_status') ?>" method="post">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Reject Application</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="application_id" value="<?= $application['ApplicationID'] ?>">
                                                        <input type="hidden" name="status" value="rejected">
                                                        <div class="mb-3">
                                                            <label for="notes" class="form-label">Reason for Rejection</label>
                                                            <textarea name="notes" class="form-control" rows="3" required></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-danger">Reject</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Payment Modal -->
                                    <div class="modal fade" id="paymentModal<?= $application['ApplicationID'] ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?= site_url('memberships/update_payment_status') ?>" method="post">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Update Payment Status</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="payment_id" value="<?= $application['PaymentID'] ?? '' ?>">
                                                        <div class="mb-3">
                                                            <label for="status" class="form-label">Payment Status</label>
                                                            <select name="status" class="form-select" required>
                                                                <option value="completed">Completed</option>
                                                                <option value="failed">Failed</option>
                                                                <option value="refunded">Refunded</option>
                                                            </select>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="transaction_id" class="form-label">Transaction ID (Optional)</label>
                                                            <input type="text" name="transaction_id" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-primary">Update Payment</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else : ?>
                    <p>No applications found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
