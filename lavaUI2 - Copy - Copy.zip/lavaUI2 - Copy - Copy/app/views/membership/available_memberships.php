<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Membership Plans</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .membership-card {
            height: 100%;
            transition: transform 0.2s;
        }
        .membership-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .price {
            font-size: 2rem;
            font-weight: bold;
            color: #0d6efd;
        }
        .duration {
            font-size: 1.1rem;
            color: #6c757d;
        }
        .benefits {
            min-height: 100px;
        }
    </style>
</head>
<body>
    <?php include 'app/views/templates/sidenav.php'; ?>

    <div class="container mt-4">
        <h1 class="mb-4">Available Membership Plans</h1>

        <?php if (isset($_SESSION['alert'])) : ?>
            <div class="alert alert-<?= $_SESSION['alert']['type'] ?> alert-dismissible fade show" role="alert">
                <?= $_SESSION['alert']['message'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Membership Plans -->
        <div class="row row-cols-1 row-cols-md-3 g-4 mb-4">
            <?php if (!empty($memberships)) : ?>
                <?php foreach ($memberships as $membership) : ?>
                    <div class="col">
                        <div class="card membership-card">
                            <div class="card-body">
                                <h3 class="card-title text-center mb-4"><?= $membership['MembershipType'] ?></h3>
                                
                                <div class="text-center mb-4">
                                    <div class="price">$<?= number_format($membership['MembershipPrice'], 2) ?></div>
                                    <div class="duration">
                                        <?= $membership['DurationInMonths'] ?> 
                                        <?= $membership['DurationInMonths'] == 1 ? 'Month' : 'Months' ?>
                                    </div>
                                </div>

                                <div class="benefits mb-4">
                                    <h5>Benefits:</h5>
                                    <p class="card-text"><?= nl2br($membership['MembershipInfo']) ?></p>
                                </div>

                                <div class="text-center">
                                    <button type="button" class="btn btn-primary btn-lg" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#applyModal<?= $membership['MembershipID'] ?>">
                                        Apply Now
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Apply Modal -->
                    <div class="modal fade" id="applyModal<?= $membership['MembershipID'] ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="<?= site_url('memberships/apply_membership') ?>" method="post">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Apply for <?= $membership['MembershipType'] ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="membership_id" value="<?= $membership['MembershipID'] ?>">
                                        
                                        <div class="mb-4">
                                            <h6>Membership Details:</h6>
                                            <p><strong>Type:</strong> <?= $membership['MembershipType'] ?></p>
                                            <p><strong>Duration:</strong> <?= $membership['DurationInMonths'] ?> Months</p>
                                            <p><strong>Price:</strong> $<?= number_format($membership['MembershipPrice'], 2) ?></p>
                                        </div>

                                        <div class="mb-4">
                                            <h6>Benefits:</h6>
                                            <p><?= nl2br($membership['MembershipInfo']) ?></p>
                                        </div>

                                        <div class="alert alert-info">
                                            <small>
                                                By applying for this membership, you agree to our terms and conditions. 
                                                Your application will be reviewed by our team, and you will be notified 
                                                of the status via email.
                                            </small>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Confirm Application</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <div class="col">
                    <div class="alert alert-info">
                        No membership plans are currently available. Please check back later.
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Information Section -->
        <div class="card mb-4">
            <div class="card-body">
                <h4>How It Works</h4>
                <ol>
                    <li>Choose a membership plan that suits your needs</li>
                    <li>Submit your application</li>
                    <li>Wait for approval from our team</li>
                    <li>Once approved, complete the payment</li>
                    <li>Start enjoying your membership benefits!</li>
                </ol>

                <h4 class="mt-4">Need Help?</h4>
                <p>
                    If you have any questions about our membership plans or need assistance, 
                    please don't hesitate to contact our support team.
                </p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
