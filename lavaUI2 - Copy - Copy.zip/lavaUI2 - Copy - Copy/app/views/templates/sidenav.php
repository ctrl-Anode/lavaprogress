<div class="col-md-4">
    <div class="card mb-2">
        <div class="card-header">Dashboard</div>
        <div class="card-body">
            <div class="list-group-flush">
                <?php if(!logged_in()): ?>
                    <a href="<?=site_url('auth/login');?>" class="list-group-item"><i class="bi bi-box-arrow-in-right"></i> Login</a>
                    <a href="<?=site_url('auth/register');?>" class="list-group-item"><i class="bi bi-person-plus"></i> Register</a>
                <?php else: ?>
                    <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                        <!-- Admin Navigation -->
                        <a href="<?=site_url('admin/dashboard');?>" class="list-group-item"><i class="bi bi-speedometer2"></i> Admin Dashboard</a>
                        <a href="<?=site_url('admin/memberships');?>" class="list-group-item"><i class="bi bi-card-list"></i> Manage Memberships</a>
                        <a href="<?=site_url('admin/applications');?>" class="list-group-item"><i class="bi bi-file-earmark-text"></i> Manage Applications</a>
                    <?php else: ?>
                        <!-- User Navigation -->
                        <a href="<?=site_url('dashboard');?>" class="list-group-item"><i class="bi bi-house"></i> Dashboard</a>
                        <a href="<?=site_url('memberships');?>" class="list-group-item"><i class="bi bi-card-list"></i> Available Memberships</a>
                        <a href="<?=site_url('memberships/my-applications');?>" class="list-group-item"><i class="bi bi-file-text"></i> My Applications</a>
                        <a href="<?=site_url('memberships/my-membership');?>" class="list-group-item"><i class="bi bi-person-badge"></i> My Membership</a>
                    <?php endif; ?>
                    
                    <!-- Common Navigation for Logged In Users -->
                    <div class="dropdown-divider"></div>
                    <a href="#" data-bs-toggle="modal" data-bs-target="#updateProfile" class="list-group-item">
                        <i class="bi bi-person-lines-fill"></i> Update Profile
                    </a>
                    <a href="#" data-bs-toggle="modal" data-bs-target="#updatePassword" class="list-group-item">
                        <i class="bi bi-pencil-square"></i> Change Password
                    </a>
                    <a href="<?=site_url('auth/logout');?>" class="list-group-item text-danger">
                        <i class="bi bi-box-arrow-right"></i> Logout
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
