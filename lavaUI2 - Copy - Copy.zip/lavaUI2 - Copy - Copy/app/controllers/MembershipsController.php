<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class MembershipsController extends Controller {
    public function __construct() {
        parent::__construct();
        $this->call->model('memberships_model');
        $this->call->library('session');
        $this->call->library('form_validation');
        
        // Check if user is logged in
        if (!logged_in()) {
            set_flash_alert('danger', 'Please login to access this page.');
            redirect('auth/login');
            return;
        }
    }

    private function check_admin() {
        $user_id = $this->session->userdata('user_id');
        if (!$user_id || $this->session->userdata('role') !== 'admin') {
            set_flash_alert('danger', 'Access denied. Admin privileges required.');
            redirect('memberships/user_dashboard');
            return false;
        }
        return true;
    }

    // Admin Dashboard
    public function admin_dashboard() {
        if (!$this->check_admin()) return;
        
        $data = array(
            'stats' => $this->memberships_model->get_application_stats(),
            'recent_applications' => $this->memberships_model->get_recent_applications(),
            'membership_stats' => $this->get_membership_stats(),
            'payment_stats' => $this->get_payment_stats()
        );
        $this->call->view('membership/admin_dashboard', $data);
    }

    // Admin Reports and Analytics
    public function get_membership_stats() {
        if (!$this->check_admin()) return;
        
        return array(
            'total_active' => $this->memberships_model->count_active_memberships(),
            'total_expired' => $this->memberships_model->count_expired_memberships(),
            'expiring_soon' => $this->memberships_model->count_expiring_memberships(),
            'total_cancelled' => $this->memberships_model->count_cancelled_memberships()
        );
    }

    public function get_payment_stats() {
        if (!$this->check_admin()) return;
        
        return array(
            'total_revenue' => $this->memberships_model->calculate_total_revenue(),
            'pending_payments' => $this->memberships_model->count_pending_payments(),
            'completed_payments' => $this->memberships_model->count_completed_payments(),
            'failed_payments' => $this->memberships_model->count_failed_payments()
        );
    }

    public function get_application_stats() {
        if (!$this->check_admin()) return;
        
        return $this->memberships_model->get_application_stats();
    }

    // Admin Membership Management
    public function read() {
        if (!$this->check_admin()) return;
        
        $data['memberships'] = $this->memberships_model->read();
        $this->call->view('membership/view_mem', $data);
    }

    public function create() {
        if (!$this->check_admin()) return;

        if($this->form_validation->submitted()) {
            $this->form_validation
                ->name('MembershipType')->required('Membership Type is required!')
                ->name('MembershipPrice')->required('Membership Price is required!')
                ->name('MembershipInfo')->required('Membership Info is required!')
                ->name('DurationInMonths')->required('Duration is required!');

            if($this->form_validation->run()) {
                $data = array(
                    'MembershipType' => $this->io->post('MembershipType'),
                    'MembershipPrice' => $this->io->post('MembershipPrice'),
                    'MembershipInfo' => $this->io->post('MembershipInfo'),
                    'DurationInMonths' => $this->io->post('DurationInMonths')
                );

                if($this->memberships_model->apply($data['MembershipType'], $data['MembershipPrice'], 
                   $data['MembershipInfo'], $data['DurationInMonths'])) {
                    set_flash_alert('success', 'Membership plan created successfully!');
                    redirect('admin/memberships');
                } else {
                    set_flash_alert('danger', 'Failed to create membership plan.');
                    redirect('admin/memberships/create');
                }
            } else {
                set_flash_alert('danger', $this->form_validation->errors());
                redirect('admin/memberships/create');
            }
        }
        $this->call->view('membership/add_mem');
    }

    public function update($id) {
        if (!$this->check_admin()) return;

        if ($this->form_validation->submitted()) {
            $this->form_validation
                ->name('MembershipType')->required('Membership Type is required!')
                ->name('MembershipPrice')->required('Membership Price is required!')
                ->name('MembershipInfo')->required('Membership Info is required!')
                ->name('DurationInMonths')->required('Duration is required!');

            if ($this->form_validation->run()) {
                $data = array(
                    'MembershipType' => $this->io->post('MembershipType'),
                    'MembershipPrice' => $this->io->post('MembershipPrice'),
                    'MembershipInfo' => $this->io->post('MembershipInfo'),
                    'DurationInMonths' => $this->io->post('DurationInMonths')
                );

                if ($this->memberships_model->update($id, $data)) {
                    set_flash_alert('success', 'Membership plan updated successfully!');
                    redirect('admin/memberships');
                } else {
                    set_flash_alert('danger', 'Failed to update membership plan.');
                }
            } else {
                set_flash_alert('danger', $this->form_validation->errors());
            }
        }

        $data['membership'] = $this->memberships_model->get_one($id);
        if (!$data['membership']) {
            set_flash_alert('danger', 'Membership plan not found.');
            redirect('admin/memberships');
            return;
        }
        $this->call->view('membership/edit_mem', $data);
    }

    public function delete($id) {
        if (!$this->check_admin()) return;

        if($this->memberships_model->delete($id)) {
            set_flash_alert('success', 'Membership plan deleted successfully!');
        } else {
            set_flash_alert('danger', 'Failed to delete membership plan!');
        }
        redirect('admin/memberships');
    }

    // Admin Application Management
    public function manage_applications() {
        if (!$this->check_admin()) return;

        $data['applications'] = $this->memberships_model->get_all_applications();
        $this->call->view('membership/manage_applications', $data);
    }

    public function update_application_status() {
        if (!$this->check_admin()) return;

        if($this->form_validation->submitted()) {
            $this->form_validation
                ->name('application_id')->required('Application ID is required.')
                ->name('status')->required('Status is required.');

            if ($this->form_validation->run()) {
                $application_id = $this->io->post('application_id');
                $status = $this->io->post('status');
                $notes = $this->io->post('notes');

                if($this->memberships_model->update_application_status($application_id, $status, $notes)) {
                    set_flash_alert('success', 'Application status updated successfully!');
                } else {
                    set_flash_alert('danger', 'Failed to update application status!');
                }
            } else {
                set_flash_alert('danger', $this->form_validation->errors());
            }
        }
        redirect('admin/applications');
    }

    public function update_payment_status() {
        if (!$this->check_admin()) return;

        if($this->form_validation->submitted()) {
            $this->form_validation
                ->name('payment_id')->required('Payment ID is required.')
                ->name('status')->required('Status is required.');

            if ($this->form_validation->run()) {
                $payment_id = $this->io->post('payment_id');
                $status = $this->io->post('status');
                $transaction_id = $this->io->post('transaction_id');

                if($this->memberships_model->update_payment_status($payment_id, $status, $transaction_id)) {
                    set_flash_alert('success', 'Payment status updated successfully!');
                } else {
                    set_flash_alert('danger', 'Failed to update payment status!');
                }
            } else {
                set_flash_alert('danger', $this->form_validation->errors());
            }
        }
        redirect('admin/applications');
    }

    // Admin Maintenance Tasks
    public function check_expiring_memberships() {
        if (!$this->check_admin()) return;
        
        $this->memberships_model->check_expiring_memberships();
        set_flash_alert('success', 'Expiring memberships checked and notifications sent.');
        redirect('admin/dashboard');
    }

    public function expire_memberships() {
        if (!$this->check_admin()) return;
        
        $this->memberships_model->expire_memberships();
        set_flash_alert('success', 'Expired memberships processed and notifications sent.');
        redirect('admin/dashboard');
    }

    // User Membership Views
    public function available_memberships() {
        $data['memberships'] = $this->memberships_model->get_active_memberships();
        $this->call->view('membership/available_memberships', $data);
    }

    public function apply_membership() {
        if(!$this->form_validation->submitted()) {
            redirect('memberships');
            return;
        }

        $this->form_validation
            ->name('membership_id')->required('Please select a membership plan.');

        if(!$this->form_validation->run()) {
            set_flash_alert('danger', $this->form_validation->errors());
            redirect('memberships');
            return;
        }

        $user_id = $this->session->userdata('user_id');
        $membership_id = $this->io->post('membership_id');

        // Check if user already has an active membership
        $active_membership = $this->memberships_model->get_user_active_membership($user_id);
        if ($active_membership) {
            set_flash_alert('danger', 'You already have an active membership.');
            redirect('memberships');
            return;
        }

        // Check if user has a pending application
        $pending_applications = $this->memberships_model->get_user_applications($user_id);
        foreach ($pending_applications as $app) {
            if ($app['Status'] === 'pending') {
                set_flash_alert('danger', 'You already have a pending membership application.');
                redirect('memberships');
                return;
            }
        }

        if($this->memberships_model->submit_application($user_id, $membership_id)) {
            set_flash_alert('success', 'Membership application submitted successfully!');
            redirect('memberships/my-applications');
        } else {
            set_flash_alert('danger', 'Failed to submit application!');
            redirect('memberships');
        }
    }

    public function my_applications() {
        $user_id = $this->session->userdata('user_id');
        $data['applications'] = $this->memberships_model->get_user_applications($user_id);
        $this->call->view('membership/my_applications', $data);
    }

    public function my_membership() {
        $user_id = $this->session->userdata('user_id');
        $data['active_membership'] = $this->memberships_model->get_user_active_membership($user_id);
        $data['membership_history'] = $this->memberships_model->get_user_membership_history($user_id);
        $this->call->view('membership/my_membership', $data);
    }

    // User Dashboard
    public function user_dashboard() {
        $user_id = $this->session->userdata('user_id');
        $data['active_membership'] = $this->memberships_model->get_user_active_membership($user_id);
        $data['recent_applications'] = $this->memberships_model->get_user_applications($user_id);
        $this->call->view('membership/user_dashboard', $data);
    }

    // Membership Actions
    public function renew_membership() {
        if(!$this->form_validation->submitted()) {
            redirect('memberships/my-membership');
            return;
        }

        $this->form_validation
            ->name('user_membership_id')->required('Membership ID is required.');

        if(!$this->form_validation->run()) {
            set_flash_alert('danger', $this->form_validation->errors());
            redirect('memberships/my-membership');
            return;
        }

        $user_membership_id = $this->io->post('user_membership_id');

        if($this->memberships_model->renew_membership($user_membership_id)) {
            set_flash_alert('success', 'Renewal application submitted successfully!');
            redirect('memberships/my-applications');
        } else {
            set_flash_alert('danger', 'Failed to submit renewal application!');
            redirect('memberships/my-membership');
        }
    }

    public function cancel_membership() {
        if(!$this->form_validation->submitted()) {
            redirect('memberships/my-membership');
            return;
        }

        $this->form_validation
            ->name('user_membership_id')->required('Membership ID is required.');

        if(!$this->form_validation->run()) {
            set_flash_alert('danger', $this->form_validation->errors());
            redirect('memberships/my-membership');
            return;
        }

        $user_membership_id = $this->io->post('user_membership_id');

        if($this->memberships_model->cancel_membership($user_membership_id)) {
            set_flash_alert('success', 'Membership cancelled successfully!');
        } else {
            set_flash_alert('danger', 'Failed to cancel membership!');
        }
        redirect('memberships/my-membership');
    }
}
?>
