<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class Memberships_model extends Model {
    // Admin Statistics Functions
    public function count_active_memberships() {
        return count($this->db->table('UserMemberships')
                            ->where('Status', 'active')
                            ->where('EndDate >= ?', [date('Y-m-d')])
                            ->get_all());
    }

    public function count_expired_memberships() {
        return count($this->db->table('UserMemberships')
                            ->where('Status', 'expired')
                            ->get_all());
    }

    public function count_cancelled_memberships() {
        return count($this->db->table('UserMemberships')
                            ->where('Status', 'cancelled')
                            ->get_all());
    }

    public function count_expiring_memberships() {
        $thirty_days = date('Y-m-d', strtotime('+30 days'));
        $today = date('Y-m-d');
        
        return count($this->db->table('UserMemberships')
                            ->where('Status', 'active')
                            ->where('EndDate BETWEEN ? AND ?', [$today, $thirty_days])
                            ->get_all());
    }

    public function calculate_total_revenue() {
        $result = $this->db->table('MembershipPayments')
                          ->where('PaymentStatus', 'completed')
                          ->select_sum('Amount')
                          ->get();
        return $result['Amount'] ?? 0;
    }

    public function count_pending_payments() {
        return count($this->db->table('MembershipPayments')
                            ->where('PaymentStatus', 'pending')
                            ->get_all());
    }

    public function count_completed_payments() {
        return count($this->db->table('MembershipPayments')
                            ->where('PaymentStatus', 'completed')
                            ->get_all());
    }

    public function count_failed_payments() {
        return count($this->db->table('MembershipPayments')
                            ->where('PaymentStatus', 'failed')
                            ->get_all());
    }

    // Admin Functions
    public function read() {
        return $this->db->table('Memberships')->get_all();
    }

    public function apply($MembershipType, $MembershipPrice, $MembershipInfo, $DurationInMonths) {
        $userdata = array(
            'MembershipType' => $MembershipType,
            'MembershipPrice' => $MembershipPrice,
            'MembershipInfo' => $MembershipInfo,
            'DurationInMonths' => $DurationInMonths,
            'Status' => 'active'
        );
        return $this->db->table('Memberships')->insert($userdata);
    }

    public function get_one($id) {
        return $this->db->table('Memberships')->where('MembershipID', $id)->get();
    }

    public function update($id, $data) {
        $userdata = [
            'MembershipType' => $data['MembershipType'],
            'MembershipPrice' => $data['MembershipPrice'],
            'MembershipInfo' => $data['MembershipInfo'],
            'DurationInMonths' => $data['DurationInMonths']
        ];
        return $this->db->table('Memberships')->where('MembershipID', $id)->update($userdata);
    }
    
    public function delete($id) {
        return $this->db->table('Memberships')->where('MembershipID', $id)->delete();
    }

    // Application Management
    public function submit_application($user_id, $membership_id) {
        // First verify that the user exists
        $user = $this->db->table('userstb')->where('id', $user_id)->get();
        if (!$user) {
            return false;
        }

        // Then verify that the membership exists
        $membership = $this->db->table('Memberships')->where('MembershipID', $membership_id)->get();
        if (!$membership) {
            return false;
        }

        // Check if user already has a pending application
        $pending = $this->db->table('MembershipApplications')
                           ->where('UserID', $user['id'])
                           ->where('Status', 'pending')
                           ->get();
        if ($pending) {
            return false;
        }

        // If all checks pass, proceed with the application
        $data = array(
            'UserID' => $user['id'],
            'MembershipID' => $membership['MembershipID'],
            'Status' => 'pending',
            'AppliedDate' => date('Y-m-d H:i:s')
        );
        
        if ($this->db->table('MembershipApplications')->insert($data)) {
            // Create payment record
            $payment_data = array(
                'ApplicationID' => $this->db->insert_id(),
                'Amount' => $membership['MembershipPrice'],
                'PaymentStatus' => 'pending'
            );
            $this->db->table('MembershipPayments')->insert($payment_data);
            
            // Create notification
            $this->create_notification($user['id'], 'application_status', 
                'Membership Application Received',
                'Your membership application has been received and is under review.');
            
            return true;
        }
        return false;
    }

    public function update_application_status($application_id, $status, $notes = null) {
        $data = array(
            'Status' => $status,
            'Notes' => $notes
        );
        
        // Get application details
        $application = $this->db->table('MembershipApplications')
                              ->where('ApplicationID', $application_id)
                              ->get();
        
        if ($status === 'approved') {
            $data['ApprovedDate'] = date('Y-m-d H:i:s');
            
            // Get membership details
            $membership = $this->get_one($application['MembershipID']);
            
            // Create user membership
            $start_date = date('Y-m-d');
            $end_date = date('Y-m-d', strtotime("+{$membership['DurationInMonths']} months"));
            
            $membership_data = array(
                'user_id' => $application['UserID'],
                'MembershipID' => $application['MembershipID'],
                'StartDate' => $start_date,
                'EndDate' => $end_date,
                'Status' => 'active'
            );
            
            $this->db->table('UserMemberships')->insert($membership_data);
            
            // Create notification
            $this->create_notification($application['UserID'], 'application_status',
                'Membership Application Approved',
                'Your membership application has been approved! Your membership is now active.');
        } elseif ($status === 'rejected') {
            // Create notification
            $this->create_notification($application['UserID'], 'application_status',
                'Membership Application Rejected',
                'Your membership application has been rejected. Reason: ' . $notes);
        }
        
        return $this->db->table('MembershipApplications')
                       ->where('ApplicationID', $application_id)
                       ->update($data);
    }

    public function get_all_applications() {
        return $this->db->table('MembershipApplications ma')
                       ->join('Memberships m', 'ma.MembershipID = m.MembershipID')
                       ->join('userstb u', 'ma.UserID = u.id')
                       ->join('MembershipPayments mp', 'ma.ApplicationID = mp.ApplicationID', 'left')
                       ->select('ma.*, m.MembershipType, m.MembershipPrice, u.username, u.email, mp.PaymentStatus, mp.PaymentID')
                       ->order_by('ma.AppliedDate', 'DESC')
                       ->get_all();
    }

    // Dashboard Statistics
    public function get_application_stats() {
        $stats = array(
            'total' => count($this->db->table('MembershipApplications')->get_all()),
            'pending' => count($this->db->table('MembershipApplications')->where('Status', 'pending')->get_all()),
            'approved' => count($this->db->table('MembershipApplications')->where('Status', 'approved')->get_all()),
            'rejected' => count($this->db->table('MembershipApplications')->where('Status', 'rejected')->get_all()),
            'cancelled' => count($this->db->table('MembershipApplications')->where('Status', 'cancelled')->get_all())
        );
        return $stats;
    }

    public function get_recent_applications() {
        return $this->db->table('MembershipApplications ma')
                       ->join('Memberships m', 'ma.MembershipID = m.MembershipID')
                       ->join('userstb u', 'ma.UserID = u.id')
                       ->join('MembershipPayments mp', 'ma.ApplicationID = mp.ApplicationID', 'left')
                       ->select('ma.*, m.MembershipType, m.MembershipPrice, u.username, u.email, mp.PaymentStatus, mp.PaymentID')
                       ->order_by('ma.AppliedDate', 'DESC')
                       ->limit(5)
                       ->get_all();
    }

    // User Functions
    public function get_user_applications($user_id) {
        return $this->db->table('MembershipApplications ma')
                       ->join('Memberships m', 'ma.MembershipID = m.MembershipID')
                       ->join('MembershipPayments mp', 'ma.ApplicationID = mp.ApplicationID', 'left')
                       ->select('ma.*, m.MembershipType, m.MembershipPrice, mp.PaymentStatus, mp.PaymentID')
                       ->where('ma.UserID', $user_id)
                       ->get_all();
    }

    public function get_user_active_membership($user_id) {
        $current_date = date('Y-m-d');
        return $this->db->table('UserMemberships um')
                       ->join('Memberships m', 'um.MembershipID = m.MembershipID')
                       ->select('um.*, m.MembershipType, m.MembershipPrice, m.MembershipInfo, m.DurationInMonths')
                       ->where('um.user_id', $user_id)
                       ->where('um.Status', 'active')
                       ->where('um.EndDate >= ?', [$current_date])
                       ->get();
    }

    public function get_user_membership_history($user_id) {
        return $this->db->table('UserMemberships um')
                       ->join('Memberships m', 'um.MembershipID = m.MembershipID')
                       ->select('um.*, m.MembershipType, m.MembershipPrice')
                       ->where('um.user_id', $user_id)
                       ->order_by('um.StartDate', 'DESC')
                       ->get_all();
    }

    public function get_active_memberships() {
        return $this->db->table('Memberships')
                       ->where('Status', 'active')
                       ->get_all();
    }

    // Maintenance Functions
    public function check_expiring_memberships() {
        $expiry_date = date('Y-m-d', strtotime('+7 days'));
        $memberships = $this->db->table('UserMemberships um')
                               ->join('userstb u', 'um.user_id = u.id')
                               ->where('um.Status', 'active')
                               ->where('um.EndDate', $expiry_date)
                               ->get_all();
        
        foreach ($memberships as $membership) {
            $this->create_notification($membership['user_id'], 'membership_expiring',
                'Membership Expiring Soon',
                'Your membership will expire in 7 days. Please renew to continue enjoying our services.');
        }
        
        return count($memberships);
    }

    public function expire_memberships() {
        $current_date = date('Y-m-d');
        $expired = $this->db->table('UserMemberships')
                           ->where('Status', 'active')
                           ->where('EndDate < ?', [$current_date])
                           ->update(['Status' => 'expired']);
        
        if ($expired) {
            $memberships = $this->db->table('UserMemberships um')
                                   ->join('userstb u', 'um.user_id = u.id')
                                   ->where('um.Status', 'expired')
                                   ->where('um.EndDate', $current_date)
                                   ->get_all();
            
            foreach ($memberships as $membership) {
                $this->create_notification($membership['user_id'], 'membership_expired',
                    'Membership Expired',
                    'Your membership has expired. Please renew to continue accessing our services.');
            }
        }
        
        return $expired;
    }

    // Notification Management
    public function create_notification($user_id, $type, $subject, $message) {
        $data = array(
            'UserID' => $user_id,
            'Type' => $type,
            'Subject' => $subject,
            'Message' => $message,
            'Status' => 'pending'
        );
        return $this->db->table('EmailNotifications')->insert($data);
    }

    public function get_pending_notifications() {
        return $this->db->table('EmailNotifications')
                       ->where('Status', 'pending')
                       ->get_all();
    }

    public function mark_notification_sent($notification_id) {
        return $this->db->table('EmailNotifications')
                       ->where('NotificationID', $notification_id)
                       ->update([
                           'Status' => 'sent',
                           'SentAt' => date('Y-m-d H:i:s')
                       ]);
    }
}
?>
