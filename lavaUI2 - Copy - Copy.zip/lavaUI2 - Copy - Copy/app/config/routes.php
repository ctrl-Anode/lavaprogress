<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

// Default Routes
$router->get('/', 'Auth');
$router->get('/home', 'Home');

// Auth Routes Group
$router->group('/auth', function() use ($router){
    $router->match('/register', 'Auth::register', ['POST', 'GET']);
    $router->match('/login', 'Auth::login', ['POST', 'GET']);
    $router->get('/logout', 'Auth::logout');
    $router->match('/password-reset', 'Auth::password_reset', ['POST', 'GET']);
    $router->match('/set-new-password', 'Auth::set_new_password', ['POST', 'GET']);
});

// Admin Membership Routes
$router->group('/admin', function() use ($router){
    // Dashboard and Statistics
    $router->get('/dashboard', 'MembershipsController::admin_dashboard');
    
    // Membership Management
    $router->get('/memberships', 'MembershipsController::read');
    $router->match('/memberships/create', 'MembershipsController::create', ['POST', 'GET']);
    $router->match('/memberships/update/{id}', 'MembershipsController::update', ['POST', 'GET']);
    $router->get('/memberships/delete/{id}', 'MembershipsController::delete');
    
    // Application Management
    $router->get('/applications', 'MembershipsController::manage_applications');
    $router->post('/applications/update-status', 'MembershipsController::update_application_status');
    $router->post('/applications/update-payment', 'MembershipsController::update_payment_status');
    
    // Maintenance Tasks
    $router->get('/maintenance/check-expiring', 'MembershipsController::check_expiring_memberships');
    $router->get('/maintenance/process-expired', 'MembershipsController::expire_memberships');
    
    // Reports and Analytics
    $router->get('/reports/membership-stats', 'MembershipsController::get_membership_stats');
    $router->get('/reports/payment-stats', 'MembershipsController::get_payment_stats');
    $router->get('/reports/application-stats', 'MembershipsController::get_application_stats');
});

// User Membership Routes
$router->group('/memberships', function() use ($router){
    // Available Memberships
    $router->get('/', 'MembershipsController::available_memberships');
    $router->post('/apply', 'MembershipsController::apply_membership');
    
    // User Dashboard and Management
    $router->get('/dashboard', 'MembershipsController::user_dashboard');
    $router->get('/my-applications', 'MembershipsController::my_applications');
    $router->get('/my-membership', 'MembershipsController::my_membership');
    
    // Membership Actions
    $router->post('/renew', 'MembershipsController::renew_membership');
    $router->post('/cancel', 'MembershipsController::cancel_membership');
});

// User Auth Routes
$router->get('/user', 'UserAuth');
$router->group('/user', function() use ($router){
    $router->match('/register', 'UserAuth::user_register', ['POST', 'GET']);
    $router->match('/login', 'UserAuth::user_login', ['POST', 'GET']);
    $router->get('/logout', 'UserAuth::user_logout');
    $router->match('/user_password-reset', 'UserAuth::user_password_reset', ['POST', 'GET']);
    $router->match('/set-new-password', 'UserAuth::user_set_new_password', ['POST', 'GET']);
});

// Terms Routes
$router->group('/terms', function() use ($router){
    $router->get('/display', 'TermsController::read');
    $router->match('/create', 'TermsController::create', ['POST', 'GET']);
    $router->match('/update', 'TermsController::update', ['POST', 'GET']);
    $router->match('/update/{TermID}', 'TermsController::update', ['POST', 'GET']);
    $router->get('/delete/{TermID}', 'TermsController::delete');
});

// Classes Routes
$router->group('/class', function() use ($router){
    $router->get('/display', 'ClassesController::read');
    $router->match('/add', 'ClassesController::create', ['POST', 'GET']);
    $router->match('/update', 'ClassesController::update', ['POST', 'GET']);
    $router->match('/update/{ClassID}', 'ClassesController::update', ['POST', 'GET']);
    $router->get('/delete/{ClassID}', 'ClassesController::delete');
});
