-- Add Status field to Memberships table
ALTER TABLE `Memberships` 
ADD COLUMN `Status` ENUM('active', 'inactive') NOT NULL DEFAULT 'active';

-- Add Status and EndDate fields to UserMemberships table
ALTER TABLE `UserMemberships` 
ADD COLUMN `Status` ENUM('active', 'cancelled', 'expired') NOT NULL DEFAULT 'active',
ADD COLUMN `EndDate` DATE NOT NULL;

-- Create MembershipApplications table
CREATE TABLE `MembershipApplications` (
  `ApplicationID` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `UserID` INT NOT NULL,
  `MembershipID` INT NOT NULL,
  `Status` ENUM('pending', 'approved', 'rejected', 'cancelled') NOT NULL DEFAULT 'pending',
  `AppliedDate` DATETIME NOT NULL,
  `ApprovedDate` DATETIME DEFAULT NULL,
  `Notes` TEXT DEFAULT NULL,
  FOREIGN KEY (`UserID`) REFERENCES `userstb`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`MembershipID`) REFERENCES `Memberships`(`MembershipID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create MembershipPayments table
CREATE TABLE `MembershipPayments` (
  `PaymentID` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `ApplicationID` INT NOT NULL,
  `Amount` DECIMAL(10, 2) NOT NULL,
  `PaymentDate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `PaymentStatus` ENUM('pending', 'completed', 'failed', 'refunded') NOT NULL DEFAULT 'pending',
  `PaymentMethod` VARCHAR(50) DEFAULT NULL,
  `TransactionID` VARCHAR(100) DEFAULT NULL,
  FOREIGN KEY (`ApplicationID`) REFERENCES `MembershipApplications`(`ApplicationID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create EmailNotifications table
CREATE TABLE `EmailNotifications` (
  `NotificationID` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `UserID` INT NOT NULL,
  `Type` ENUM('application_status', 'payment_status', 'membership_expiring', 'membership_expired') NOT NULL,
  `Status` ENUM('pending', 'sent', 'failed') NOT NULL DEFAULT 'pending',
  `Subject` VARCHAR(255) NOT NULL,
  `Message` TEXT NOT NULL,
  `CreatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `SentAt` DATETIME DEFAULT NULL,
  FOREIGN KEY (`UserID`) REFERENCES `userstb`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
