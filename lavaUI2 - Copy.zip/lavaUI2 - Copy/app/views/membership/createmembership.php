<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gym Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Full height layout */
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        /* Sidebar styling */
        .sidebar {
            background-color: #f8f9fa;
            height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: 250px;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            padding: 10px 20px;
            text-decoration: none;
            font-size: 16px;
            color: #333;
            transition: background 0.3s;
        }

        .sidebar a:hover {
            background-color: #e9ecef;
        }

        .sidebar a .icon {
            margin-right: 10px;
        }

        /* Main content styling */
        .main-content {
            margin-left: 250px;
            padding: 20px;
            background-color: #f1f3f5;
            min-height: 100vh;
        }

        /* Navbar styling */
        .navbar-custom {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
            padding: 15px;
        }
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width:2000px;
            margin-top: 20px;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #f8f9fa;
            position: fixed;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        body {
                background-color: #f8f9fa;
            }
            .form-container {
                background-color: #ffffff;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            .form-label {
                font-weight: bold;
            }
            .custom-header {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .custom-header h1 {
            margin: 0;}
    </style>
</head>
<body>
<?php
// Predefined membership details
$membershipDetails = [
    "Weekly" => [
        "price" => 100,
        "info" => "Basic weekly plan",
        "benefits" => "Access to standard features for 7 days",
        "duration" => "7 days",
        "terms" => "No refunds after purchase"
    ],
    "Monthly" => [
        "price" => 350,
        "info" => "Standard monthly plan",
        "benefits" => "Access to standard features for 30 days",
        "duration" => "30 days",
        "terms" => "No refunds after purchase"
    ],
    "Yearly" => [
        "price" => 4000,
        "info" => "Premium yearly plan",
        "benefits" => "Access to all features for 1 year",
        "duration" => "365 days",
        "terms" => "No refunds after purchase"
    ]
];

// Initialize variables
$selectedType = $_POST['membership_type'] ?? '';
$membershipData = $selectedType && isset($membershipDetails[$selectedType]) ? $membershipDetails[$selectedType] : [
    "price" => "",
    "info" => "",
    "benefits" => "",
    "duration" => "",
    "terms" => ""
];
?>
    <!-- Sidebar -->
    <div class="sidebar">
        <a href="#" class="navbar-brand mx-3 mb-4">
            <strong>Gym Management System</strong>
        </a>
        <a class="nav-link" href="#"><?=html_escape(get_username(get_user_id()));?></a><br>
        <a href="homepage">
            <span class="icon">📊</span> Dashboard
        </a>
        <a href="/user/display">
            <span class="icon">👤</span> Members
        </a>
        <a href="#">
            <span class="icon">📅</span> Classes
        </a>
        <a href="#">
            <span class="icon">💳</span> Payments
        </a>
        <div class="sidebar">
    <h4 class="p-3">Gym Management</h4>
    <nav class="nav flex-column">
        <a class="nav-link" href="/user/add" >Add Members</a>
        <a class="nav-link" href="#" onclick="showSection('membership')">Apply for Membership</a>
        <a class="nav-link" href="#" onclick="showSection('class-booking')">Book a Class</a>
        <a class="nav-link" href="#" onclick="showSection('member-management')">Member Management</a>
        <a class="nav-link" href="#" onclick="showSection('payment-processing')">Payment Processing</a><br>
                <li class="nav-item">
                    <a class="nav-link" href="<?=site_url('auth/logout');?>">Logout</a>
                </li>
    </nav>
    </div>
        <a href="#">
            <span class="icon">⚙️</span> Settings
        </a>
        <a href="#" class="mt-auto">
            <span class="icon">↩️</span> Logout
        </a>
    </div>
    <main>
            <div class="container">
                <div class="row mt-3">
                    <div class="col-sm-6 mx-auto">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <!-- Breadcrumb items -->
                            </ol>
                        </nav>
                        <h2>Add New Users</h2><br><br>
                        <?php flash_alert() ?>
                        <div class="form-container">
                            <form action="<?= site_url('membership/apply'); ?>" method="POST">
                            <div class="mb-3">
            <label for="membership_type" class="form-label">Membership Type</label>
            <input type="text" class="form-control" id="membership_type" name="membership_type" required>
        </div>
        <div class="mb-3">
            <label for="membership_price" class="form-label">Membership Price</label>
            <input type="number" class="form-control" id="membership_price" name="membership_price" required>
        </div>
        <div class="mb-3">
            <label for="membership_info" class="form-label">Membership Info</label>
            <input type="text" class="form-control" id="membership_info" name="membership_info" required>
        </div>
        <div class="mb-3">
            <label for="membership_benefits" class="form-label">Membership Benefits</label>
            <input type="text" class="form-control" id="membership_benefits" name="membership_benefits" required>
        </div>
        <div class="mb-3">
            <label for="membership_duration" class="form-label">Membership Duration</label>
            <input type="text" class="form-control" id="membership_duration" name="membership_duration" required>
        </div>
        <div class="mb-3">
            <label for="membership_term_con" class="form-label">Membership Terms and Conditions</label>
            <input type="text" class="form-control" id="membership_term_con" name="membership_term_con" required>
        </div>
                                <button type="submit" name="submit" class="btn btn-primary">Apply</button>
                                <a href="<?= site_url('user/display'); ?>" class="btn btn-secondary" role="button">User List</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</body>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</body>
</html>

