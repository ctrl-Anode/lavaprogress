<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gym Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Full height layout */
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        /* Sidebar styling */
        .sidebar {
            background-color: #f8f9fa;
            height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: 250px;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            padding: 10px 20px;
            text-decoration: none;
            font-size: 16px;
            color: #333;
            transition: background 0.3s;
        }

        .sidebar a:hover {
            background-color: #e9ecef;
        }

        .sidebar a .icon {
            margin-right: 10px;
        }

        /* Main content styling */
        .main-content {
            margin-left: 250px;
            padding: 20px;
            background-color: #f1f3f5;
            min-height: 100vh;
        }

        /* Navbar styling */
        .navbar-custom {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
            padding: 15px;
        }
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width:2000px;
            margin-top: 20px;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #f8f9fa;
            position: fixed;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        body {
                background-color: #f8f9fa;
            }
            .form-container {
                background-color: #ffffff;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            .form-label {
                font-weight: bold;
            }
            .custom-header {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .custom-header h1 {
            margin: 0;}
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <a href="#" class="navbar-brand mx-3 mb-4">
            <strong>Gym Management System</strong>
        </a>
        <a class="nav-link" href="#"><?=html_escape(get_username(get_user_id()));?></a><br>
        <a href="homepage">
            <span class="icon">📊</span> Dashboard
        </a>
        <a href="/user/display">
            <span class="icon">👤</span> Members
        </a>
        <a href="#">
            <span class="icon">📅</span> Classes
        </a>
        <a href="#">
            <span class="icon">💳</span> Payments
        </a>
        <div class="sidebar">
    <h4 class="p-3">Gym Management</h4>
    <nav class="nav flex-column">
        <a class="nav-link" href="/user/add" >Add Members</a>
        <a class="nav-link" href="#" onclick="showSection('membership')">Apply for Membership</a>
        <a class="nav-link" href="#" onclick="showSection('class-booking')">Book a Class</a>
        <a class="nav-link" href="#" onclick="showSection('member-management')">Member Management</a>
        <a class="nav-link" href="#" onclick="showSection('payment-processing')">Payment Processing</a><br>
                <li class="nav-item">
                    <a class="nav-link" href="<?=site_url('auth/logout');?>">Logout</a>
                </li>
    </nav>
    </div>
        <a href="#">
            <span class="icon">⚙️</span> Settings
        </a>
        <a href="#" class="mt-auto">
            <span class="icon">↩️</span> Logout
        </a>
    </div>
    <main>
        <div class="container">
            <div class="row mt-3">
                <div class="col-sm-6 mx-auto">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?=site_url('user/add');?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Update User's Info</li>
                        </ol>
                    </nav>
                    <h2>Update User's Info</h2>
                    <?php flash_alert()?>
                    <form action="/membership/update/<?= $mem['membership_id']; ?>" method="POST">
                    <div class="mb-3">
                            <label class="form-label">Type</label>
                            <input type="text" class="form-control" placeholder="" name="membership_type" value="<?= $mem['membership_type']; ?>" required autocomplete="off">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Price</label>
                            <input type="text" class="form-control" placeholder="" name="membership_price" value="<?= $mem['membership_price']; ?>" required autocomplete="off">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Info</label>
                            <input type="text" class="form-control" placeholder="" name="membership_info" value="<?= $mem['membership_info']; ?>" required autocomplete="off">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Benefits</label>
                            <input type="text" class="form-control" placeholder="" name="membership_benefits" value="<?= $mem['membership_benefits']; ?>" required autocomplete="off">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Duration</label>
                            <input type="text" class="form-control" placeholder="" name="membership_duration" value="<?= $mem['membership_duration']; ?>" required autocomplete="off">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <input type="text" name="password" placeholder="" name="membership_term_con" value="<?= $mem['membership_term_con']; ?>" required autocomplete="off">
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">Update</button>
                        <a href="<?=site_url('membership/display');?>" class="btn btn-primary" role="button">User List</a>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</body>
</html>