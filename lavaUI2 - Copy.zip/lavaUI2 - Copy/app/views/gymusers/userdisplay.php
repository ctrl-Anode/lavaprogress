<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gym Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* General styles */
        body,
        html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        /* Sidebar styling */
        .sidebar {
            background-color: #f8f9fa;
            height: 100vh;
            width: 250px;
            position: fixed;
            padding-top: 20px;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            padding: 10px 20px;
            text-decoration: none;
            font-size: 16px;
            color: #333;
            transition: background 0.3s;
        }

        .sidebar a:hover {
            background-color: #e9ecef;
        }

        .sidebar .icon {
            margin-right: 10px;
        }

        /* Main content styling */
        .main-content {
            margin-left: 250px;
            padding: 20px;
            background-color: #f1f3f5;
            min-height: 100vh;
        }

        /* Table styling */
        table {
            background-color: #fff;
        }

        .form-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .pagination {
            margin-top: 20px;
        }
    </style>
</head>
<?php
require 'conn.php';

$search = $_GET['search'] ?? '';
$page = $_GET['page'] ?? 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM fitnessgymusers WHERE last_name LIKE ? OR first_name LIKE ?");
$total_stmt->execute(["%$search%", "%$search%"]);
$total_rows = $total_stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT * FROM fitnessgymusers WHERE last_name LIKE ? OR first_name LIKE ? LIMIT ? OFFSET ?");
$stmt->execute(["%$search%", "%$search%", $limit, $offset]);
$user = $stmt->fetchAll();

$total_pages = ceil($total_rows / $limit);
?>

<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <a href="#" class="navbar-brand mx-3 mb-4">
            <strong>Gym Management System</strong>
        </a>
        <a href="#" class="nav-link"><?= html_escape(get_username(get_user_id())); ?></a>
        <a href="homepage"><span class="icon">📊</span> Dashboard</a>
        <a href="/user/display"><span class="icon">👤</span> Members</a>
        <a href="#"><span class="icon">📅</span> Classes</a>
        <a href="#"><span class="icon">💳</span> Payments</a>
        <a href="/user/add"><span class="icon">➕</span> Add Members</a>
        <a href="#" onclick="showSection('membership')">Apply for Membership</a>
        <a href="#" onclick="showSection('class-booking')">Book a Class</a>
        <a href="#" onclick="showSection('member-management')">Member Management</a>
        <a href="#" onclick="showSection('payment-processing')">Payment Processing</a>
        <a href="#"><span class="icon">⚙️</span> Settings</a>
        <a href="<?= site_url('auth/logout'); ?>" class="mt-auto"><span class="icon">↩️</span> Logout</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="mb-3">
        <label for="search" class="form-label">Search using First or Last Name</label>
        <div class="input-group">
            <input type="text" name="search" id="search" placeholder="Type lastname or firstname" class="form-control" value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </div>

        <?php flash_alert(); ?>

        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Middle Name</th>
                        <th>Last Name</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Contact</th>
                        <th>Gender</th>
                        <th>Address</th>
                        <th>Password</th>
                        <th>Modify</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?= $user['id']; ?></td>
                            <td><?= $user['first_name']; ?></td>
                            <td><?= $user['middle_name']; ?></td>
                            <td><?= $user['last_name']; ?></td>
                            <td><?= $user['username']; ?></td>
                            <td><?= $user['email']; ?></td>
                            <td><?= $user['contact']; ?></td>
                            <td><?= $user['gender']; ?></td>
                            <td><?= $user['address']; ?></td>
                            <td><?= $user['password']; ?></td>
                            <td>
                                <a href="<?= site_url('user/update/' . $user['id']); ?>" class="btn btn-primary btn-sm">Update</a>
                                <a href="<?= site_url('user/delete/' . $user['id']); ?>" class="btn btn-danger btn-sm">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="pagination">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?search=<?php echo htmlspecialchars($search); ?>&page=<?php echo $i; ?>" class="btn btn-sm btn-secondary"><?php echo $i; ?></a>
            <?php endfor; ?>
        </div>
        <a href="<?= site_url('user/add'); ?>" class="btn btn-primary mt-3">Add New</a>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
