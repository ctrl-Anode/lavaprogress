<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class MembershipsController extends Controller {
    public function __construct()
    {
        parent:: __construct();
        $this->call->model('memberships_model');
    }
	public function read()
    {
        $userdata['memberships']=$this->memberships_model->read();
        $this->call->view('membership/view_mem', $userdata);
    }
    public function apply()
    {
        if($this->form_validation->submitted()){
            $this->form_validation
                ->name('MembershipType')
                     ->required('MembershipType is required!')
                ->name('MembershipPrice')
                     ->required('MembershipPrice is required!')
                ->name('MembershipInfo')
                     ->required('MembershipInfo is required!')
                ->name('DurationInMonths')
                     ->required('DurationInMonths is required!');
        if($this->form_validation->run()){
            $MembershipType = $this->io->post('MembershipType');
            $MembershipPrice = $this->io->post('MembershipPrice');
            $MembershipInfo = $this->io->post('MembershipInfo');
            $DurationInMonths = $this->io->post('DurationInMonths');

            if($this->memberships_model->apply($MembershipType, $MembershipPrice, $MembershipInfo, $DurationInMonths)){
               set_flash_alert('success', 'Membership Application succesful!');
               redirect('memberships/display');
            }
        }
        else{
               set_flash_alert('danger', $this->form_validation->errors());
               redirect('memberships/apply');
        }
        }
        $this->call->view('membership/add_mem');
    }
    public function update($id)
{
    if ($this->form_validation->submitted()) {
        // Define validation rules
        $this->form_validation
        ->name('MembershipType')
        ->required('MembershipType is required!')
   ->name('MembershipPrice')
        ->required('MembershipPrice is required!')
   ->name('MembershipInfo')
        ->required('MembershipInfo is required!')
   ->name('DurationInMonths')
        ->required('DurationInMonths is required!');

        // Run validation
        if ($this->form_validation->run()) {
            // Collect form data
            $data = [
                'MembershipType' => $this->io->post('MembershipType'),
                'MembershipPrice' => $this->io->post('MembershipPrice'),
                'MembershipInfo' => $this->io->post('MembershipInfo'),
                'DurationInMonths' => $this->io->post('DurationInMonths'),
            ];

            // Update user data in the database
            if ($this->memberships_model->update($id, $data)) {
                set_flash_alert('success', ' data was updated successfully!');
                redirect('memberships/display');
                return;
            } else {
                set_flash_alert('danger', 'Failed to update user data.');
                redirect('memberships/display');
                return;
            }
        } else {
            // Handle validation errors
            set_flash_alert('danger', $this->form_validation->errors());
            redirect('memberships/display');
            return;
        }
    }

    // Load user data for the view
    $userdata['membership'] = $this->memberships_model->get_one($id);
    $this->call->view('membership/edit_mem', $userdata);
}

    public function delete($id){
        if($this->memberships_model->delete($id)){
            set_flash_alert('success', 'User data was deleted successfully!');
            redirect('memberships/display');
        }else{
            set_flash_alert('danger', 'Something Went Wrong!');
            redirect('memberships/display');
        }
    }
    
}
?>
